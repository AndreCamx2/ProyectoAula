package com.farmall.controller;

import com.farmall.model.Product;
import com.farmall.model.User;
import com.farmall.model.User.Role;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador para gestionar operaciones CRUD de productos.
 * Sólo usuarios con rol ADMIN pueden modificar datos.
 */
public class ProductController {
    private List<Product> products = new ArrayList<>();

    /**
     * Verifica que el usuario sea administrador.
     */
    private void checkAdmin(User user) {
        if (user == null || user.getRole() != Role.ADMIN) {
            throw new SecurityException("Operación reservada a administradores.");
        }
    }

    /**
     * Agrega un nuevo producto.
     * @param product Producto a agregar (no null).
     * @param user Usuario que realiza la operación (debe ser ADMIN).
     * @return true si se agregó correctamente, false si ya existe un producto con el mismo ID.
     */
    public boolean addProduct(Product product, User user) {
        checkAdmin(user);
        if (product == null) {
            throw new IllegalArgumentException("El producto no puede ser null.");
        }
        if (getProductById(product.getId()) != null) {
            return false;
        }
        products.add(product);
        return true;
    }

    /**
     * Obtiene un producto por su ID.
     * @param id ID del producto a buscar.
     * @return Producto si se encuentra, null en caso contrario.
     */
    public Product getProductById(int id) {
        for (Product p : products) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    /**
     * Actualiza un producto existente.
     * @param updated Producto con datos actualizados (debe tener ID válido).
     * @param user Usuario que realiza la operación (debe ser ADMIN).
     * @return true si la actualización fue exitosa, false si no existe el producto.
     */
    public boolean updateProduct(Product updated, User user) {
        checkAdmin(user);
        if (updated == null) {
            throw new IllegalArgumentException("El producto actualizado no puede ser null.");
        }
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId() == updated.getId()) {
                products.set(i, updated);
                return true;
            }
        }
        return false;
    }

    /**
     * Elimina un producto por su ID.
     * @param id ID del producto a eliminar.
     * @param user Usuario que realiza la operación (debe ser ADMIN).
     * @return true si se eliminó, false si no se encontró.
     */
    public boolean removeProduct(int id, User user) {
        checkAdmin(user);
        Product existing = getProductById(id);
        if (existing != null) {
            products.remove(existing);
            return true;
        }
        return false;
    }

    /**
     * Obtiene la lista completa de productos.
     * @return Nueva lista con los productos actuales.
     */
    public List<Product> getAllProducts() {
        return new ArrayList<>(products);
    }
}
