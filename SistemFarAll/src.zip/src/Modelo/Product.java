package com.farmall.model;

/**
 * Representa un producto en FarmAll.
 */
public class Product {
    private int id;
    private String name;
    private String description;
    private double price;
    private int quantity;

    /**
     * Constructor para inicializar un producto con validaciones.
     * @param id Identificador único (debe ser positivo).
     * @param name Nombre del producto (no nulo, no vacío, máximo 30 caracteres, solo letras y espacios).
     * @param description Descripción (puede ser vacía).
     * @param price Precio unitario (>= 0).
     * @param quantity Cantidad en stock (>= 0).
     */
    public Product(int id, String name, String description, double price, int quantity) {
        setId(id);
        setName(name);
        setDescription(description);
        setPrice(price);
        setQuantity(quantity);
    }

    // ===== Getters =====
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }

    // ===== Setters con validaciones =====

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser un número positivo.");
        }
        this.id = id;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del producto no puede estar vacío.");
        }
        String trimmed = name.trim();
        if (trimmed.length() > 30) {
            throw new IllegalArgumentException("El nombre del producto no puede exceder 30 caracteres.");
        }
        if (!trimmed.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ ]+")) {
            throw new IllegalArgumentException("El nombre del producto solo puede contener letras y espacios.");
        }
        this.name = trimmed;
    }

    public void setDescription(String description) {
        this.description = (description != null) ? description.trim() : "";
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        this.price = price;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        }
        this.quantity = quantity;
    }
}
