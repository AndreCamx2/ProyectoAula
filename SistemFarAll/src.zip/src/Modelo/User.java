package com.farmall.model;

/**
 * Representa un usuario del sistema FarmAll.
 */
public class User {
    public enum Role { ADMIN, USER }

    private int id;
    private String name;
    private String phoneNumber;
    private Role role;

    /**
     * Constructor para inicializar un usuario con validaciones.
     * @param id Identificador único (debe ser positivo).
     * @param name Nombre del usuario (no nulo, máximo 30 caracteres, solo letras y espacios).
     * @param phoneNumber Número de teléfono (solo dígitos, sin símbolos).
     * @param role Rol del usuario (ADMIN o USER).
     */
    public User(int id, String name, String phoneNumber, Role role) {
        setId(id);
        setName(name);
        setPhoneNumber(phoneNumber);
        setRole(role);
    }

    // ===== Getters =====
    public int getId() { return id; }
    public String getName() { return name; }
    public String getPhoneNumber() { return phoneNumber; }
    public Role getRole() { return role; }

    // ===== Setters con validaciones =====

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser un número positivo.");
        }
        this.id = id;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        String trimmed = name.trim();
        if (trimmed.length() > 30) {
            throw new IllegalArgumentException("El nombre no puede exceder 30 caracteres.");
        }
        if (!trimmed.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ ]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras y espacios.");
        }
        this.name = trimmed;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || !phoneNumber.matches("\\d+")) {
            throw new IllegalArgumentException("El número de teléfono solo puede contener dígitos.");
        }
        this.phoneNumber = phoneNumber;
    }

    public void setRole(Role role) {
        if (role == null) {
            throw new IllegalArgumentException("El rol no puede ser null.");
        }
        this.role = role;
    }
}
