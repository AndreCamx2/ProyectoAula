
package Vista;

import Controlador.Ctrl_Producto;
import Controlador.Ctrl_Categoria;
import Modelo.Producto;
import Modelo.Categoria;
import java.awt.Dimension;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Optional;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmGestionarProducto extends javax.swing.JInternalFrame {

    private int idProducto;

    public FrmGestionarProducto() {
        initComponents();
        this.setSize(new Dimension(900, 500));
        this.setTitle("Gestionar Productos");
        CargarTablaProductos();
        CargarComboCategoria();
    }

    private void CargarComboCategoria() {
        try {
            Ctrl_Categoria ctrlCategoria = new Ctrl_Categoria();
            ctrlCategoria.cargarDesdeJson(Path.of("src/Datos/categorias.json"));
            DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
            modelo.addElement("Seleccione categoria:");
            for (Categoria c : ctrlCategoria.listarTodos()) {
                modelo.addElement(c.getDescripcion());
            }
            jComboBox_categoria.setModel(modelo);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar categorías: " + e.getMessage());
        }
    }

    private void CargarTablaProductos() {
        try {
            Ctrl_Producto ctrlProducto = new Ctrl_Producto();
            ctrlProducto.cargarDesdeJson(Path.of("src/Datos/productos.json"));
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(new String[]{"ID", "Nombre", "Cantidad", "Precio", "Descripción", "IVA", "Categoría"});
            for (Producto p : ctrlProducto.listarTodos()) {
                model.addRow(new Object[]{
                    p.getId(),
                    p.getNombre(),
                    p.getCantidad(),
                    p.getPrecio(),
                    p.getDescripcion(),
                    p.getPorcentajeIva(),
                    p.getCategoria()
                });
            }
            jTable_productos.setModel(model);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }

    private void EnviarDatosProductoSeleccionado(int idProducto) {
        try {
            Ctrl_Producto ctrlProducto = new Ctrl_Producto();
            ctrlProducto.cargarDesdeJson(Path.of("src/Datos/productos.json"));
            Optional<Producto> opt = ctrlProducto.listarTodos()
                .stream()
                .filter(p -> p.getId() == idProducto)
                .findFirst();

            if (opt.isPresent()) {
                Producto p = opt.get();
                txt_nombre.setText(p.getNombre());
                txt_cantidad.setText(String.valueOf(p.getCantidad()));
                txt_precio.setText(String.valueOf(p.getPrecio()));
                txt_descripcion.setText(p.getDescripcion());
                switch (p.getPorcentajeIva()) {
                    case 0 -> jComboBox_iva.setSelectedItem("No grava iva");
                    case 12 -> jComboBox_iva.setSelectedItem("12%");
                    case 14 -> jComboBox_iva.setSelectedItem("14%");
                    default -> jComboBox_iva.setSelectedItem("Seleccione iva:");
                }
                jComboBox_categoria.setSelectedItem(p.getCategoria());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar producto seleccionado: " + e.getMessage());
        }
    }

    private int IdCategoria() {
        try {
            Ctrl_Categoria ctrlCategoria = new Ctrl_Categoria();
            ctrlCategoria.cargarDesdeJson(Path.of("src/Datos/categorias.json"));
            String descripcion = jComboBox_categoria.getSelectedItem().toString();
            Optional<Categoria> cat = ctrlCategoria.listarTodos()
                .stream()
                .filter(c -> c.getDescripcion().equalsIgnoreCase(descripcion))
                .findFirst();
            return cat.map(Categoria::getId).orElse(-1);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener id de categoría: " + e.getMessage());
            return -1;
        }
    }
}
