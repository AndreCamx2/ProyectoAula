
package Vista;

import Controlador.Ctrl_Cliente;
import Modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.nio.file.Path;
import java.util.List;

public class InterGestionarCliente extends javax.swing.JInternalFrame {

    private JTable tabla;
    private DefaultTableModel modelo;
    private Ctrl_Cliente controlador;

    public InterGestionarCliente() {
        initComponents();
        setTitle("Gestión de Clientes");
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setSize(700, 400);
        cargarClientes();
    }

    private void initComponents() {
        modelo = new DefaultTableModel(new Object[]{"Cédula", "Nombre", "Apellido", "Dirección", "Teléfono"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(scroll, java.awt.BorderLayout.CENTER);
    }

    private void cargarClientes() {
        try {
            controlador = new Ctrl_Cliente();
            controlador.cargarDesdeJson(Path.of("src/Datos/clientes.json"));
            List<Cliente> lista = controlador.listarClientes();
            modelo.setRowCount(0);
            for (Cliente c : lista) {
                modelo.addRow(new Object[]{
                        c.getCedula(), c.getNombre(), c.getApellido(),
                        c.getDireccion(), c.getTelefono()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
        }
    }
}
