
package Vista;

import Controlador.Ctrl_Usuario;
import Modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class FrmGestionarUsuario extends javax.swing.JInternalFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public FrmGestionarUsuario() {
        initComponents();
        setTitle("Gestión de Usuarios");
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setSize(600, 400);
        cargarUsuarios();
    }

    private void initComponents() {
        modelo = new DefaultTableModel(new Object[]{"Usuario", "Nombre", "Apellido", "Teléfono"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(scroll, java.awt.BorderLayout.CENTER);
    }

    private void cargarUsuarios() {
        Ctrl_Usuario controlador = new Ctrl_Usuario();
        List<Usuario> lista = controlador.listarTodos();
        modelo.setRowCount(0);
        for (Usuario u : lista) {
            modelo.addRow(new Object[]{
                u.getUsuario(),
                u.getNombre(),
                u.getApellido(),
                u.getTelefono()
            });
        }
    }
}
